public class Like {
    private User user;

    public Like(User user) {
        this.user = user;
    }
}
