// Social Media Platform
import java.util.ArrayList;
public class SocialMediaPlatform {
    public static void main(String[] args) {
        User user1 = new User("Guljahon", "guli@gmail.com");
        User user2 = new User("Sarah", "sara@msagroupllc.com");

        Post post1 = new Post(user1, "Hello, friends! #welcome");
        Comment comment1 = new Comment(user2, "Hi there!");

        post1.addComment(comment1);
        post1.likePost(user2);

        Notification notification = new Notification(user1, "You have a new friend request!");
        System.out.println(notification.getMessage());
    }
}








