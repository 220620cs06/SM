import java.util.ArrayList;

import java.util.Date;
import java.util.List;

public class Event
{
    private String eventName;
    private Date date;
    private List<User> attendees;

    public Event(String eventName, Date date) {
        this.eventName = eventName;
        this.date = date;
        this.attendees = new ArrayList<>();
    }

    public void addAttendee(User user) {
        attendees.add(user);
    }
}
